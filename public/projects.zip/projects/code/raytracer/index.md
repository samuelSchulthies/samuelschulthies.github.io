+++
date = '2026-11-24T10:27:56-07:00'
draft = false
title = 'Raytracer'
+++

[cascade.params]
projectgroup = "code"

![Raytracer preview](featured.png)